import discord
from discord import app_commands
from discord.ext import commands
import datetime
import pytz  # 한국 시간을 사용하기 위해 pytz를 임포트

# 한국 시간대 (UTC+9)
KST = pytz.timezone('Asia/Seoul')

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

channel_id_store = {}
log_channel_store = {}
message_store = {
    "출근": "출근했습니다!",
    "퇴근": "퇴근했습니다!"
}
personal_message_store = {}
work_log = {}
work_tag_store = {}

@bot.event
async def on_ready():
    await tree.sync()
    print(f"봇 로그인: {bot.user}")

@tree.command(name="출근", description="출근을 기록합니다.")
async def 출근(interaction: discord.Interaction):
    now = datetime.datetime.now(KST)  # 한국 시간으로 현재 시간 얻기
    user = interaction.user
    if user.id in work_log:
        await interaction.response.send_message("이미 출근하셨습니다.", ephemeral=True)
        return
    work_log[user.id] = now
    message = personal_message_store.get(user.id, {}).get("출근", message_store["출근"])
    embed = discord.Embed(title="📥 출근 기록", description=message, color=discord.Color.green())
    embed.set_author(name=user.display_name)
    embed.set_thumbnail(url=user.display_avatar.url)
    embed.add_field(name="출근 시간", value=now.strftime("%Y-%m-%d %H:%M:%S"), inline=False)
    if user.id in work_tag_store:
        embed.add_field(name="근무 태그", value=work_tag_store[user.id], inline=False)
    await send_to_channel(interaction.guild_id, embed, channel_id_store)
    await send_to_channel(interaction.guild_id, embed, log_channel_store)
    await user.send("출근이 정상적으로 기록되었습니다.")
    await interaction.response.send_message("출근이 기록되었습니다.", ephemeral=True)

@tree.command(name="퇴근", description="퇴근을 기록합니다.")
async def 퇴근(interaction: discord.Interaction):
    now = datetime.datetime.now(KST)  # 한국 시간으로 현재 시간 얻기
    user = interaction.user
    start = work_log.pop(user.id, None)
    if not start:
        await interaction.response.send_message("출근 기록이 없습니다.", ephemeral=True)
        return
    delta = str(now - start).split('.')[0]
    message = personal_message_store.get(user.id, {}).get("퇴근", message_store["퇴근"])
    embed = discord.Embed(title="📤 퇴근 기록", description=message, color=discord.Color.blue())
    embed.set_author(name=user.display_name)
    embed.set_thumbnail(url=user.display_avatar.url)
    embed.add_field(name="퇴근 시간", value=now.strftime("%Y-%m-%d %H:%M:%S"), inline=False)
    embed.add_field(name="근무 시간", value=delta, inline=False)
    if user.id in work_tag_store:
        embed.add_field(name="근무 태그", value=work_tag_store[user.id], inline=False)
    await send_to_channel(interaction.guild_id, embed, channel_id_store)
    await send_to_channel(interaction.guild_id, embed, log_channel_store)
    await user.send(f"퇴근이 기록되었습니다. 총 근무 시간: {delta}")
    await interaction.response.send_message("퇴근이 기록되었습니다.", ephemeral=True)

async def send_to_channel(guild_id, embed, store):
    channel_id = store.get(guild_id)
    if channel_id:
        channel = bot.get_channel(channel_id)
        if channel:
            await channel.send(embed=embed)


@tree.command(name="메시지설정", description="출퇴근 메시지를 설정합니다.")
async def 메시지설정(interaction: discord.Interaction, 타입: str, 메시지: str):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("관리자만 사용할 수 있습니다.", ephemeral=True)
        return
    if 타입 not in ["출근", "퇴근"]:
        await interaction.response.send_message("출근 또는 퇴근만 가능합니다.", ephemeral=True)
        return
    message_store[타입] = 메시지
    await interaction.response.send_message(f"{타입} 메시지가 설정되었습니다.", ephemeral=True)

@tree.command(name="메시지개인화", description="개인 출퇴근 메시지를 설정합니다.")
async def 메시지개인화(interaction: discord.Interaction, 타입: str, 메시지: str):
    if 타입 not in ["출근", "퇴근"]:
        await interaction.response.send_message("출근 또는 퇴근만 가능합니다.", ephemeral=True)
        return
    if interaction.user.id not in personal_message_store:
        personal_message_store[interaction.user.id] = {}
    personal_message_store[interaction.user.id][타입] = 메시지
    await interaction.response.send_message(f"{타입} 개인 메시지가 설정되었습니다.", ephemeral=True)

@tree.command(name="로그설정", description="출퇴근 로그를 전송할 채널을 설정합니다.")
@app_commands.checks.has_permissions(administrator=True)
async def 로그설정(interaction: discord.Interaction, 채널: discord.TextChannel):
    log_channel_store[interaction.guild_id] = 채널.id
    await interaction.response.send_message(f"출퇴근 로그 채널이 {채널.mention} 으로 설정되었습니다.", ephemeral=True)

@tree.command(name="기록조회", description="자신 또는 특정 사용자의 출퇴근 기록을 조회합니다.")
async def 기록조회(interaction: discord.Interaction, 사용자: discord.User = None):
    user = 사용자 or interaction.user
    if user.id in work_log:
        출근시간 = work_log[user.id].strftime("%Y-%m-%d %H:%M:%S")
        태그 = work_tag_store.get(user.id, "없음")
        await interaction.response.send_message(f"{user.display_name}님의 출근 시간: {출근시간}\n근무 태그: {태그}", ephemeral=True)
    else:
        await interaction.response.send_message(f"{user.display_name}님은 출근하지 않았습니다.", ephemeral=True)

@tree.command(name="근무태그", description="현재 근무에 사용할 태그를 설정합니다.")
async def 근무태그(interaction: discord.Interaction, 태그: str):
    work_tag_store[interaction.user.id] = 태그
    await interaction.response.send_message(f"근무 태그가 '{태그}'(으)로 설정되었습니다.", ephemeral=True)

@tree.command(name="출퇴근기록조회", description="특정 사용자의 출퇴근 기록을 관리자 권한으로 확인합니다.")
@app_commands.checks.has_permissions(administrator=True)
async def 출퇴근기록조회(interaction: discord.Interaction, 사용자: discord.User):
    user_id = 사용자.id
    출근기록 = work_log.get(user_id)
    태그 = work_tag_store.get(user_id, "없음")

    if 출근기록:
        now = datetime.datetime.now()
        근무시간 = str(now - 출근기록).split('.')[0]
        메시지 = (
            f"**{사용자.display_name}** 님은 현재 출근 중입니다.\n"
            f"출근 시간: `{출근기록.strftime('%Y-%m-%d %H:%M:%S')}`\n"
            f"근무 시간: `{근무시간}`\n"
            f"근무 태그: `{태그}`"
        )
    else:
        메시지 = f"**{사용자.display_name}** 님은 현재 출근 중이 아닙니다.\n"
        메시지 += f"근무 태그: `{태그}`"

    await interaction.response.send_message(메시지, ephemeral=True)

async def send_to_channel(guild_id, embed, store):
    channel_id = store.get(guild_id)
    if channel_id:
        channel = bot.get_channel(channel_id)
        if channel:
            await channel.send(embed=embed)

@tree.command(name="출퇴근채널설정", description="출퇴근 메시지를 보낼 채널을 설정합니다. (관리자 전용)")
@app_commands.describe(channel="출퇴근 메시지를 보낼 채널을 선택하세요.")
async def 출퇴근채널설정(interaction: discord.Interaction, channel: discord.TextChannel):
    # 관리자 권한 확인
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("이 명령어는 관리자만 사용할 수 있습니다.", ephemeral=True)
        return

    guild_id = interaction.guild_id
    channel_id_store[guild_id] = channel.id
    await interaction.response.send_message(f"출퇴근 채널이 {channel.mention} 로 설정되었습니다.", ephemeral=True)

from keep_alive import keep_alive
keep_alive()

# 봇 이벤트/명령어 등 작성
@bot.event
async def on_ready():
    print(f'{bot.user} is online!')

# 디스코드 봇 토큰은 비밀에 저장해둔 환경변수에서 가져오기
import os
bot.run("MTM3MDM4NDQwMTIzNzgwNzEyNQ.GasJUQ.YZyn2M9Qs3u9-1xZS0ij_u94Tg6adBxoadkwSE")
